# Chatbot tutorial

This repository accompanies [this youtube video](https://youtu.be/vTpk-PKZwTs), and works as an introduction to [react-chatbot-kit](https://fredrikoseberg.github.io/react-chatbot-kit-docs/)
